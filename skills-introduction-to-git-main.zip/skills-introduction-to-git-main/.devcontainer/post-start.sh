#!/bin/bash

# Start exercise monitor
/home/vscode/.vscode-remote/data/Machine/exercise-monitor/start.sh